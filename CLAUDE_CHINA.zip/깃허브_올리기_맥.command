#!/bin/bash
# CVT200 중국 출장 자료 — GitHub 업로드
# 사용법 : 이 파일을 더블클릭하거나 터미널에서 실행

set -u
cd "$(dirname "$0")"

echo
echo "============================================================"
echo "  CVT200 중국 출장 자료 - GitHub 업로드"
echo "  저장소 : https://github.com/cholmi1/CLAUDE_CHINA"
echo "============================================================"
echo

if ! command -v git >/dev/null 2>&1; then
  echo "[오류] Git이 설치되어 있지 않습니다."
  echo "       터미널에서  xcode-select --install  을 실행해 설치하십시오."
  echo
  read -r -p "Enter 키를 누르면 종료합니다..."
  exit 1
fi

if [ ! -d ".git" ]; then
  echo "[1/5] 저장소 초기화..."
  git init -b main
  git remote add origin https://github.com/cholmi1/CLAUDE_CHINA.git
else
  echo "[1/5] 기존 저장소 확인됨"
  git remote set-url origin https://github.com/cholmi1/CLAUDE_CHINA.git 2>/dev/null \
    || git remote add origin https://github.com/cholmi1/CLAUDE_CHINA.git
fi

echo "[2/5] 작성자 정보 설정..."
git config user.name "KANG CHOL HEE"
git config user.email "chulhee@cnvtech.co.kr"

echo "[3/5] 변경 파일 등록..."
git add -A

echo "[4/5] 커밋 생성..."
git commit -m "CVT200 중국 출장 자료 갱신 (2026.09.07-11)" 2>/dev/null \
  || echo "       변경 사항이 없거나 이미 커밋되었습니다."

echo "[5/5] GitHub 업로드..."
echo
echo "   ※ Username 물으면 : cholmi1"
echo "   ※ Password 물으면 : 계정 암호가 아니라 Personal Access Token 을 붙여넣으십시오"
echo "     (붙여넣어도 화면에 아무것도 안 보이는 것이 정상입니다. 그대로 Enter)"
echo

if git push -u origin main --force; then
  echo
  echo "============================================================"
  echo "  업로드 완료"
  echo "  https://github.com/cholmi1/CLAUDE_CHINA"
  echo "============================================================"
else
  echo
  echo "============================================================"
  echo "  업로드 실패. 아래를 확인하십시오."
  echo "  - 토큰이 유효한지 (repo 권한 필요)"
  echo "  - 저장소 주소가 맞는지"
  echo "============================================================"
fi

echo
read -r -p "Enter 키를 누르면 종료합니다..."
